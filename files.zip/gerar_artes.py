"""
Gerador de artes "Parceiro 2V" com código de cupom variável.

Como usar:
1. Coloque a arte-base (sem texto de cupom, ou com qualquer cupom) em
   template_original.png
2. Liste os códigos de cupom desejados em cupons.txt, um por linha.
3. Rode: python3 gerar_artes.py
4. As artes finais aparecem em saida/, uma por código.

O script apaga a faixa verde antiga (repintando com a cor de fundo),
depois desenha uma faixa verde NOVA cuja LARGURA se ajusta ao tamanho
do texto de cada cupom (mais um respiro/padding fixo nas laterais),
sempre centralizada no mesmo ponto horizontal da faixa original.

SOBRE A FONTE:
A arte original usa "Vinila Compressed", que é uma fonte COMERCIAL
(foundry Plau / Adobe Fonts) — não é de uso gratuito. Por padrão este
script usa "Anton" (Google Fonts, gratuita e licenciada para uso
comercial), que tem visual bem parecido (caixa-alta, compressed, bold).

Se você tiver a licença da Vinila Compressed (ex: via Adobe Fonts no
seu Mac), extraia o arquivo .otf/.ttf, coloque-o nesta mesma pasta e
troque o valor de FONT_PATH abaixo para o nome do arquivo dela.
"""

from PIL import Image, ImageDraw, ImageFont
import os

# ---------- CONFIGURAÇÃO ----------
TEMPLATE_PATH = "template_original.png"
CUPONS_PATH = "cupons.txt"
SAIDA_DIR = "saida"

FONT_PATH = "Anton-Regular.ttf"
# Para usar a Vinila Compressed real (se você tiver o arquivo licenciado):
# FONT_PATH = "VinilaCompressed-Bold.otf"

PREFIXO_TEXTO = "USE O CUPOM: "

# Coordenadas da faixa verde NA ARTE ORIGINAL (referência de tamanho/posição).
# Se você trocar de template e a faixa mudar de lugar, ajuste aqui.
BOX_LEFT = 136
BOX_RIGHT = 935
BOX_TOP = 689
BOX_BOTTOM = 795
BOX_CENTRO_X = (BOX_LEFT + BOX_RIGHT) / 2   # eixo de centralização horizontal
BOX_LARGURA_MAX = BOX_RIGHT - BOX_LEFT       # nunca passar dessa largura (limite da arte)

COR_VERDE = (55, 105, 70)        # cor de fundo da faixa
COR_TEXTO = (240, 230, 219)      # cor do texto (creme)
COR_FUNDO = (240, 230, 219)      # cor do fundo da arte (pra "apagar" a faixa antiga)

FONT_SIZE_INICIAL = 58           # tamanho de fonte de partida
PADDING_LATERAL = 45             # respiro fixo (esquerda+direita) dentro da faixa nova
# -----------------------------------


def carregar_cupons(caminho):
    with open(caminho, "r", encoding="utf-8") as f:
        linhas = [linha.strip() for linha in f if linha.strip()]
    return linhas


def ajustar_tamanho_fonte(draw, texto, fonte_path, tamanho_inicial, largura_max):
    """Reduz o tamanho da fonte até o texto caber na largura disponível."""
    tamanho = tamanho_inicial
    while tamanho > 10:
        fonte = ImageFont.truetype(fonte_path, tamanho)
        bbox = draw.textbbox((0, 0), texto, font=fonte)
        largura = bbox[2] - bbox[0]
        if largura <= largura_max:
            return fonte, bbox
        tamanho -= 2
    # fallback no menor tamanho testado
    fonte = ImageFont.truetype(fonte_path, tamanho)
    bbox = draw.textbbox((0, 0), texto, font=fonte)
    return fonte, bbox


def gerar_arte(codigo_cupom, template_img, fonte_path, saida_path):
    img = template_img.copy()
    draw = ImageDraw.Draw(img)

    # 1. apaga a faixa antiga inteira (com uma margem extra de segurança
    #    para cobrir pixels de antialiasing da borda original),
    #    repintando com a cor de fundo da arte
    MARGEM_LIMPEZA = 4
    draw.rectangle(
        [
            BOX_LEFT - MARGEM_LIMPEZA,
            BOX_TOP - MARGEM_LIMPEZA,
            BOX_RIGHT + MARGEM_LIMPEZA,
            BOX_BOTTOM + MARGEM_LIMPEZA,
        ],
        fill=COR_FUNDO,
    )

    # 2. monta o texto e ajusta fonte para caber, no máximo, na largura
    #    total disponível (caso o texto seja muito longo)
    texto = f"{PREFIXO_TEXTO}{codigo_cupom}"
    largura_disponivel = BOX_LARGURA_MAX - PADDING_LATERAL
    fonte, bbox = ajustar_tamanho_fonte(
        draw, texto, fonte_path, FONT_SIZE_INICIAL, largura_disponivel
    )

    largura_texto = bbox[2] - bbox[0]
    altura_texto = bbox[3] - bbox[1]

    # 3. calcula a largura da NOVA faixa: largura do texto + padding lateral
    largura_faixa = min(largura_texto + PADDING_LATERAL, BOX_LARGURA_MAX)
    faixa_left = BOX_CENTRO_X - largura_faixa / 2
    faixa_right = BOX_CENTRO_X + largura_faixa / 2

    # 4. desenha a faixa verde nova, já na largura certa
    draw.rectangle(
        [faixa_left, BOX_TOP, faixa_right, BOX_BOTTOM],
        fill=COR_VERDE,
    )

    # 5. centraliza o texto dentro da faixa nova
    centro_y = (BOX_TOP + BOX_BOTTOM) / 2
    x = BOX_CENTRO_X - largura_texto / 2 - bbox[0]
    y = centro_y - altura_texto / 2 - bbox[1]

    draw.text((x, y), texto, font=fonte, fill=COR_TEXTO)

    img.save(saida_path)


def main():
    if not os.path.exists(TEMPLATE_PATH):
        print(f"Erro: não encontrei {TEMPLATE_PATH}")
        return
    if not os.path.exists(CUPONS_PATH):
        print(f"Erro: não encontrei {CUPONS_PATH}")
        return

    os.makedirs(SAIDA_DIR, exist_ok=True)

    template_img = Image.open(TEMPLATE_PATH).convert("RGB")
    cupons = carregar_cupons(CUPONS_PATH)

    if not cupons:
        print("Nenhum código de cupom encontrado em cupons.txt")
        return

    for codigo in cupons:
        nome_arquivo = f"Parceiro_{codigo}.png"
        caminho_saida = os.path.join(SAIDA_DIR, nome_arquivo)
        gerar_arte(codigo, template_img, FONT_PATH, caminho_saida)
        print(f"Gerado: {caminho_saida}")

    print(f"\nConcluído! {len(cupons)} arte(s) gerada(s) em '{SAIDA_DIR}/'.")


if __name__ == "__main__":
    main()
